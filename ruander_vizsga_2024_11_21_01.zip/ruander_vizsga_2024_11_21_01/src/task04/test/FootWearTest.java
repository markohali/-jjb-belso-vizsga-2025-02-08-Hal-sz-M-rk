package task04.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import task04.app.FootWear;

public class FootWearTest {

	@Test
	public void getisNotSaleText() {
		FootWear footwear = new FootWear(1,"Nike", "Airmax 123",28900.0, Byte.parseByte("1"),false);
		String actual = footwear.getIsSaleText();
		String expected ="nem akciós";
		Assert.assertEquals(expected, actual);
	}
	@Test
	public void testGetCategoryText() {
	    FootWear footWearMale = new FootWear(1, "Nike", "Air Zoom", 15800.0, (byte) 1, false);	    
	    assertEquals("férfi", footWearMale.getCategoryText());
	   
	}
}