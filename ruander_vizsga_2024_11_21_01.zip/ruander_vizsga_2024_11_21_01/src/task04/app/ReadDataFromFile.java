package task04.app;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public class ReadDataFromFile 
{
	 public List<FootWear> readDataFromCsv() {
	        List<FootWear> footWears = new ArrayList<>();
	        
	        try {
	            BufferedReader br = new BufferedReader(
	                    new InputStreamReader(
	                            new FileInputStream("task04_data/fit_shoes.csv"), "UTF-8"));	
	            
	            @SuppressWarnings("unused")
				String header = br.readLine(); 
	            
	            while (br.ready()) {
	                String row = br.readLine();
	                footWears.add(getFootWearFromRow(row)); 
	            }
	            br.close(); 
	        } catch (UnsupportedEncodingException e) {
	            System.out.println("A kódolás megadás hibás!!!");
	        } catch (FileNotFoundException e) {
	            System.out.println("Nem találom a fájlt a megadott elérési úton!!!");
	        } catch (IOException e) {
	            System.out.println("I/O hiba történt!!!");
	        }
	        
	        return footWears; 
	    }
	

	private FootWear getFootWearFromRow(String row) {
		String[] rowData = row.split(";");
		Boolean saleTemp = rowData[5].equals("1");
		
		FootWear footWearObj = new FootWear(
		
                Integer.parseInt(rowData[0]),
                rowData[1],
                rowData[2],
                Double.parseDouble(rowData[3]),
                Byte.parseByte(rowData[4]),
                saleTemp);
		return footWearObj;
  			
	}
}
