package task04.app;

import java.util.ArrayList;
import java.util.List;

public class TaskSolution {
	
	
	 List<FootWear> footWears = new ArrayList<>();

	public void fillFootWearList() {
		
        ReadDataFromFile readDataFromFile = new ReadDataFromFile();
        footWears = readDataFromFile.readDataFromCsv();
		
		
	}
	
	public void printAllFootWearData() {
			for (FootWear footWear : footWears) {
            System.out.println(footWear.toString());
        }
	}
	
	

 public void getCheapestFootWearDetails() {
	 	double minPrice = footWears.get(0).getNetPrice();
        for (FootWear footWear : footWears) {
            if (footWear.getNetPrice() < minPrice) {
                minPrice = footWear.getNetPrice();
            }
        }
        for (FootWear footWear : footWears) {
			if (footWear.getNetPrice()==minPrice) {
				System.out.println(footWear.toString());
			}}} 
 }
