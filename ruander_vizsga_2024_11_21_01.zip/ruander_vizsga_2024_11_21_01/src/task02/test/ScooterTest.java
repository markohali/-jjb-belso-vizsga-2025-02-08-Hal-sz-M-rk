package task02.test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import task02.app.ElectricScooter;
import task02.app.Scooter;

public class ScooterTest {

	@Test
	public void isOldTest() {
		Scooter scooter = new Scooter("BestScooterFor4U", 2020, "fehér", "TRE-4456");
		Boolean actual = scooter.isOld();
		Boolean expected = false;
		Assert.assertEquals(expected, actual);
	}
	

    @Test
    public void canUseInTrafficWhenMaxSpeedIs25() {
        ElectricScooter scooter = new ElectricScooter("BestElectricRoller4U", 2022, "Fekete", "M531", 10000, 25);
        assertTrue(scooter.canUseInTraffic());
    }

    @Test
    public void canUseInTrafficWhenMaxSpeedIsLessThan25() {
        ElectricScooter scooter = new ElectricScooter("BestElectricRoller4U", 2022, "Fekete", "M531", 10000, 20);
        assertTrue(scooter.canUseInTraffic());
    }
}
