package task02.app;

	public class App {
	    public static void main(String[] args) {
	       
	        ElectricScooter scooter = new ElectricScooter("BestElectricRoller4U", 2022, "Fekete", "M531", 10000, 25);

	        System.out.println("Roller részletei: " + scooter.toString());
	        System.out.println();
	        if (scooter.canUseInTraffic()) {
	            System.out.println("Ez a roller használható a forgalomban.");
	        } else {
	            System.out.println("Ez a roller nem használható a forgalomban.");
	        }
	    }
	}

