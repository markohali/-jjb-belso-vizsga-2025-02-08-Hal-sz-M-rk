package task03.app;

import java.util.HashMap;
import java.util.Map;

public class Order {
    private Long id;
    private Map<Integer, OrderItem> orderItems;

    public Order(Long id) {
        this.id = id;
        this.orderItems = new HashMap<>(); 
    }

    public Map<Integer, OrderItem> getOrderItems() {
        return orderItems;
    }

    public Long getId() {
        return id;
    }

    public Double getTotalCost() {
        Double totalCost = 0.0;
        for (OrderItem item : orderItems.values()) {
            Food food = item.getFood();
            double itemNetPrice = food.isSale() ? food.getNetPrice() * 0.9 : food.getNetPrice();
            totalCost += itemNetPrice * item.getQuantity();
        }
        return totalCost;
    }

    public void addOrderItem(OrderItem item) {
        int newKey = orderItems.size() + 1; 
        orderItems.put(newKey, item);
    }
}