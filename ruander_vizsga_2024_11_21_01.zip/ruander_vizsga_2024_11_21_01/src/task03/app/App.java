package task03.app;

public class App {

	
	 public static void main(String[] args) {
	        Food pizzaBolognese = new Food("Pizza Bolognese", 3900.0, false);
	        Food hawaiiPizza = new Food("Hawaii Pizza", 4500.0, true);      
	        Order order = new Order(1L); 
	        order.addOrderItem(new OrderItem(pizzaBolognese, 2)); 
	        order.addOrderItem(new OrderItem(hawaiiPizza, 1)); 
	        double totalCost = order.getTotalCost();
	        System.out.println("Rendelés azonosítója: " + order.getId() + ", teljes összeg: " + totalCost + " ft");
	    }
	    
	}
