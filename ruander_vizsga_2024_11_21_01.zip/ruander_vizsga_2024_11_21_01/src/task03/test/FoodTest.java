package task03.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import task03.app.Food;

public class FoodTest {

	@Test
	public void getDiscountedPriceTest() {
		Food food = new Food("Tonhalas Pizza", 5000.0,true);
		double actual = food.getDiscountedPrice();
		double expected =4500.0;
		Assert.assertEquals(expected, actual, 0.0);
	}
	
	  @Test
	    public void getDiscountedPriceTestSale() {  
	        Food foodOnSale = new Food("Tonhalas Pizza", 5000.0, true);
	        double actualSalePrice = foodOnSale.getDiscountedPrice();
	        double expectedSalePrice = 5000.0 * 0.9; 
	        assertEquals(expectedSalePrice, actualSalePrice, 0.0);
	    }
	    @Test
	    public void getDiscountedPriceTestNoSale() {	  
	        Food foodNotOnSale = new Food("Margherita Pizza", 4000.0, false);
	        double actualNoSalePrice = foodNotOnSale.getDiscountedPrice();
	        double expectedNoSalePrice = 4000.0;
	        assertEquals(expectedNoSalePrice, actualNoSalePrice, 0.0);
	    }
}