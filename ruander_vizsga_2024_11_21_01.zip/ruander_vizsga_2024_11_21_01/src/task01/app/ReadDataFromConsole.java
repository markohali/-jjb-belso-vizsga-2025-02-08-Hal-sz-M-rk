package task01.app;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.io.IOException;

public class ReadDataFromConsole {

    public User getUserData() {
        User userObj = null;

        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.println("Kérem adja meg a Felhasználó adatait:");

            System.out.print("Vezetéknév: ");
            String lastName = br.readLine();

            System.out.print("Keresztnév: ");
            String firstName = br.readLine();

            System.out.print("Felhasználónév: ");
            String userName = br.readLine();

            LocalDate dateOfBirth = null;
            while (dateOfBirth == null) {
                try {
                    System.out.print("Születési dátum (ÉÉÉÉ-HH-NN): ");
                    dateOfBirth = LocalDate.parse(br.readLine());
                } catch (Exception e) {
                    System.out.println("Hibás formátum! Kérlek, így add meg: ÉÉÉÉ-HH-NN");
                }
            }

            byte statusByte;
            do {
                System.out.print("Aktív (1-igen, 0-nem): ");
                statusByte = Byte.parseByte(br.readLine());
            } while (statusByte != 1 && statusByte != 0);
            boolean status = statusByte == 1;

            userObj = new User(
            		firstName,
            		lastName,
            		userName,
            		dateOfBirth,
            		status);
            
        } catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return userObj;
    }
}

