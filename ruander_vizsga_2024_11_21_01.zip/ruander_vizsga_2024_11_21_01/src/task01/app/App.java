package task01.app;

public class App {

	public static void main(String[] args) {

		 ReadDataFromConsole readDataFromconsoleObj = new ReadDataFromConsole();
		 User user = readDataFromconsoleObj.getUserData();
		 System.out.println(user.toString());
		 
	}

}
