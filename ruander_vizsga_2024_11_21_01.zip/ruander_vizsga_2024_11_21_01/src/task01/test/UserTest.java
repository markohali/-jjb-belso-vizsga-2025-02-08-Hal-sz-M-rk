package task01.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import task01.app.User;

public class UserTest {

	@Test
	public void testUserStatusText() {
		User user = new User("Elek", "Teszt", "tesztelek", LocalDate.of(1999, 01,01), true);
		String actual = user.getStatusText();
		String expected = "aktív";
		Assert.assertEquals(expected, actual);
	}
	
	@Test
	public void testGetAge() {
	 
	    LocalDate birthDate = LocalDate.of(1999, 1, 1);
	    User user = new User("Elek", "Teszt", "tesztelek", birthDate, true);
	    int expectedAge = LocalDate.now().getYear() - birthDate.getYear();
	    if (LocalDate.now().isBefore(birthDate.withYear(LocalDate.now().getYear()).plusDays(1))) {
	        expectedAge--;
	    }
	    assertEquals(expectedAge, user.getAge());
	}

	@Test
	public void testGetAgeFutureBirthDate() {
	    LocalDate futureBirthDate = LocalDate.now().plusYears(1);
	    User user = new User("Elek", "Teszt", "tesztelek", futureBirthDate, true);
	    assertEquals(-1, user.getAge());
	}
}
